"""Pipeline: seed → autocomplete expansion → top results per query → gap score."""
from __future__ import annotations

import csv
import io
import os
from typing import Awaitable, Callable

import aiohttp

from scoring import analyze
from suggest import detect_lang, expand
from youtube import QuotaExceeded, YouTube

REGION = {"ru": os.getenv("REGION_RU", "RU"), "en": os.getenv("REGION_EN", "US")}
UNITS_PER_QUERY = 102

Progress = Callable[[str], Awaitable[None]]


async def find_gaps(seed: str, yt: YouTube, session: aiohttp.ClientSession,
                    top_n: int = 15, progress: Progress | None = None) -> tuple[list[dict], str | None]:
    """Returns (results sorted by score desc, warning or None)."""
    lang = detect_lang(seed)
    if progress:
        await progress("🔎 Собираю подсказки YouTube…")
    demand = await expand(session, seed, lang)
    if not demand:
        return [], "Подсказок не нашлось — попробуй более общий запрос."

    candidates = sorted(demand.items(), key=lambda kv: kv[1], reverse=True)
    affordable = yt.units_left() // UNITS_PER_QUERY
    warning = None
    if affordable < top_n:
        warning = f"Квоты хватает только на {affordable} запросов (кэшированные бесплатны)."
    candidates = candidates[:top_n]

    results = []
    for i, (q, d) in enumerate(candidates, 1):
        if progress and (i == 1 or i % 3 == 0):
            await progress(f"📊 Анализирую выдачу {i}/{len(candidates)}: «{q}»")
        try:
            videos = await yt.top_results(q, REGION[lang], lang)
        except QuotaExceeded as e:
            warning = str(e)
            break
        r = analyze(q, videos, d)
        r["suggest_demand"] = d
        results.append(r)

    results.sort(key=lambda r: r["score"], reverse=True)
    return results, warning


def to_csv(results: list[dict]) -> bytes:
    buf = io.StringIO()
    cols = ["score", "query", "demand", "supply_weakness", "median_age_days", "median_views",
            "match_share", "small_share", "outliers", "reasons"]
    w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore")
    w.writeheader()
    for r in results:
        w.writerow({**r, "reasons": "; ".join(r["reasons"])})
    return buf.getvalue().encode("utf-8-sig")  # BOM so Excel opens Cyrillic correctly
